package com.keven.messenger

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.*
import android.app.Activity

class MainActivity : Activity() {

    private val bg = Color.rgb(248, 250, 252)
    private val blue = Color.rgb(34, 158, 217)
    private val dark = Color.rgb(30, 41, 59)
    private val muted = Color.rgb(100, 116, 139)
    private val line = Color.rgb(226, 232, 240)
    private lateinit var root: LinearLayout
    private var currentChat: String? = null

    data class Chat(
        val name: String,
        val initials: String,
        val message: String,
        val time: String,
        val unread: Int = 0,
        val online: Boolean = false
    )

    private val chats = listOf(
        Chat("Alex", "A", "¿Ya viste la nueva versión?", "1:02", 2, true),
        Chat("María", "M", "Perfecto 👍", "00:48", 0, true),
        Chat("Keven Dev", "K", "El APK está listo para probar", "Ayer", 4, false),
        Chat("Soporte", "S", "Bienvenido a Keven", "Ayer"),
        Chat("Grupo Proyecto", "GP", "Carlos: envié los archivos", "Lun", 12)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            fitsSystemWindows = true
        }
        return root
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun rounded(color: Int, radius: Float = 22f, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != null) setStroke(1, stroke)
        }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showLogin() {
        val r = base()
        val space = Space(this)
        r.addView(space, LinearLayout.LayoutParams(1, 0, 1f))

        val logo = tv("K", 34f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(blue, 30f)
        }
        r.addView(logo, LinearLayout.LayoutParams(dp(78), dp(78)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })

        r.addView(tv("Keven", 30f, dark, true).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(52)))

        r.addView(tv("Mensajería sin número telefónico", 16f, muted).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(40)))

        val google = Button(this).apply {
            text = "Continuar con Google"
            textSize = 16f
            setTextColor(dark)
            background = rounded(Color.WHITE, 18f, line)
            setOnClickListener { showHome() }
        }
        r.addView(google, LinearLayout.LayoutParams(-1, dp(54)).apply {
            setMargins(dp(28), dp(24), dp(28), dp(10))
        })

        r.addView(tv("Tu correo será tu identificador. No necesitas SIM.", 13f, muted).apply {
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(48)))

        r.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        setContentView(r)
    }

    private fun showHome() {
        val r = base()

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(12), 0)
            setBackgroundColor(Color.WHITE)
        }
        toolbar.addView(tv("Keven", 25f, dark, true), LinearLayout.LayoutParams(0, dp(62), 1f))
        val search = tv("⌕", 32f, dark).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showSearch() }
        }
        toolbar.addView(search, LinearLayout.LayoutParams(dp(48), dp(62)))
        val more = tv("⋮", 30f, dark).apply { gravity = Gravity.CENTER }
        toolbar.addView(more, LinearLayout.LayoutParams(dp(38), dp(62)))
        r.addView(toolbar)

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        listOf("Todos", "No leídos", "Grupos").forEachIndexed { i, label ->
            val b = TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(if (i == 0) blue else muted)
                if (i == 0) background = rounded(Color.rgb(232, 245, 253), 18f)
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                setMargins(dp(4), 0, dp(4), 0)
            })
        }
        r.addView(tabs)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        r.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        chats.forEach { chat ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(8), dp(14), dp(8))
                setBackgroundColor(Color.WHITE)
                setOnClickListener { showChat(chat.name) }
            }

            val avatar = tv(chat.initials, 17f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER
                background = rounded(avatarColor(chat.name), 50f)
            }
            row.addView(avatar, LinearLayout.LayoutParams(dp(54), dp(54)))

            val middle = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), 0, dp(8), 0)
            }
            val name = tv(chat.name, 16f, dark, true)
            val msg = tv(chat.message, 14f, muted)
            middle.addView(name, LinearLayout.LayoutParams(-1, dp(28)))
            middle.addView(msg, LinearLayout.LayoutParams(-1, dp(25)))
            row.addView(middle, LinearLayout.LayoutParams(0, dp(70), 1f))

            val right = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
            }
            right.addView(tv(chat.time, 12f, muted), LinearLayout.LayoutParams(-1, dp(28)))
            if (chat.unread > 0) {
                val badge = tv(chat.unread.toString(), 11f, Color.WHITE, true).apply {
                    gravity = Gravity.CENTER
                    background = rounded(blue, 30f)
                }
                right.addView(badge, LinearLayout.LayoutParams(dp(25), dp(25)))
            }
            row.addView(right, LinearLayout.LayoutParams(dp(48), dp(62)))

            list.addView(row)
            list.addView(View(this).apply { setBackgroundColor(line) },
                LinearLayout.LayoutParams(-1, 1).apply { setMargins(dp(82), 0, 0, 0) })
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            elevation = dp(8).toFloat()
        }
        listOf("💬\nChats", "👥\nContactos", "📞\nLlamadas", "⚙\nAjustes").forEachIndexed { i, label ->
            val b = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(if (i == 0) blue else muted)
            }
            bottom.addView(b, LinearLayout.LayoutParams(0, dp(62), 1f))
        }
        r.addView(bottom)

        val fab = Button(this).apply {
            text = "+"
            textSize = 28f
            setTextColor(Color.WHITE)
            background = rounded(blue, 60f)
            elevation = dp(8).toFloat()
            setOnClickListener { showSearch() }
        }
        addContentView(fab, ViewGroup.LayoutParams(dp(58), dp(58)))
        fab.post {
            fab.x = resources.displayMetrics.widthPixels - dp(76).toFloat()
            fab.y = resources.displayMetrics.heightPixels - dp(160).toFloat()
        }

        setContentView(r)
    }

    private fun showSearch() {
        val r = base()
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(Color.WHITE)
        }
        val back = tv("‹", 38f, dark).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showHome() }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(45), dp(62)))
        val input = EditText(this).apply {
            hint = "Buscar por correo o ID"
            textSize = 16f
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = rounded(Color.rgb(241,245,249), 20f)
            setPadding(dp(14), 0, dp(14), 0)
        }
        bar.addView(input, LinearLayout.LayoutParams(0, dp(46), 1f))
        r.addView(bar)
        r.addView(tv("Encuentra personas sin mostrar tu número.", 14f, muted).apply {
            setPadding(dp(20), dp(18), dp(20), dp(10))
        }, LinearLayout.LayoutParams(-1, dp(50)))

        val qr = Button(this).apply {
            text = "▣  Escanear QR"
            textSize = 15f
            background = rounded(Color.WHITE, 18f, line)
            setTextColor(dark)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Escáner QR de demostración", Toast.LENGTH_SHORT).show()
            }
        }
        r.addView(qr, LinearLayout.LayoutParams(-1, dp(52)).apply {
            setMargins(dp(18), dp(4), dp(18), dp(8))
        })
        r.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        setContentView(r)
        input.requestFocus()
    }

    private fun showChat(name: String) {
        currentChat = name
        val r = base()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(10), 0)
            setBackgroundColor(Color.WHITE)
        }
        val back = tv("‹", 38f, dark).apply {
            gravity = Gravity.CENTER
            setOnClickListener { showHome() }
        }
        top.addView(back, LinearLayout.LayoutParams(dp(45), dp(62)))
        val avatar = tv(name.take(1), 15f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(avatarColor(name), 40f)
        }
        top.addView(avatar, LinearLayout.LayoutParams(dp(42), dp(42)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10),0,0,0) }
        info.addView(tv(name, 16f, dark, true), LinearLayout.LayoutParams(-1, dp(29)))
        info.addView(tv("en línea", 12f, blue), LinearLayout.LayoutParams(-1, dp(20)))
        top.addView(info, LinearLayout.LayoutParams(0, dp(62), 1f))
        top.addView(tv("☎", 22f, dark).apply {
            gravity = Gravity.CENTER
            setOnClickListener { Toast.makeText(this@MainActivity, "Llamada de demostración", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(dp(45), dp(62)))
        top.addView(tv("⋮", 26f, dark).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(35), dp(62)))
        r.addView(top)

        val messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(18), dp(12), dp(12))
        }
        val scroll = ScrollView(this).apply { addView(messages) }
        r.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        addBubble(messages, "¡Hola! Esta es la nueva interfaz de Keven.", false)
        addBubble(messages, "Se siente mucho más como una app de mensajería real 😎", false)
        addBubble(messages, "Sí, y después podemos conectar el chat real.", true)

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        val attach = tv("＋", 27f, muted).apply { gravity = Gravity.CENTER }
        composer.addView(attach, LinearLayout.LayoutParams(dp(42), dp(50)))
        val edit = EditText(this).apply {
            hint = "Escribe un mensaje"
            textSize = 15f
            singleLine = true
            background = rounded(Color.rgb(241,245,249), 24f)
            setPadding(dp(16), 0, dp(16), 0)
        }
        composer.addView(edit, LinearLayout.LayoutParams(0, dp(48), 1f))
        val send = tv("➤", 25f, blue, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener {
                val text = edit.text.toString().trim()
                if (text.isNotEmpty()) {
                    addBubble(messages, text, true)
                    edit.setText("")
                    scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
                }
            }
        }
        composer.addView(send, LinearLayout.LayoutParams(dp(48), dp(50)))
        r.addView(composer)

        setContentView(r)
    }

    private fun addBubble(parent: LinearLayout, text: String, mine: Boolean) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.RIGHT else Gravity.LEFT
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val bubble = tv(text, 15f, if (mine) Color.WHITE else dark).apply {
            setPadding(dp(15), dp(10), dp(15), dp(10))
            background = rounded(if (mine) blue else Color.WHITE, 18f)
        }
        val width = (resources.displayMetrics.widthPixels * 0.78).toInt()
        row.addView(bubble, LinearLayout.LayoutParams(width, -2))
        parent.addView(row)
    }

    private fun avatarColor(name: String): Int {
        val colors = intArrayOf(
            Color.rgb(14,165,233), Color.rgb(139,92,246),
            Color.rgb(16,185,129), Color.rgb(245,158,11),
            Color.rgb(236,72,153)
        )
        return colors[(name.hashCode() and Int.MAX_VALUE) % colors.size]
    }
}
