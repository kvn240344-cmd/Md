# Keven Messenger V2

Prototipo Android de una app de mensajería inspirada en patrones modernos de Telegram/WhatsApp, sin copiar su marca ni interfaz exacta.

Incluye:
- Pantalla principal de chats con avatares, estados, mensajes, horas y no leídos.
- Pestañas Todos / No leídos / Grupos.
- Búsqueda por correo o ID.
- Acceso de demostración con Google.
- Vista de conversación.
- Envío de mensajes localmente en la demo.
- Botón de llamada de demostración.
- Escáner QR de demostración.
- Diseño preparado para conectar backend, OAuth, contactos, llamadas y sincronización en una siguiente etapa.

Esta versión es una interfaz/prototipo: todavía no implementa autenticación Google real ni mensajería por Internet.
