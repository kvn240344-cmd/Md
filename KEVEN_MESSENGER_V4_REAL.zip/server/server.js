const WebSocket=require('ws');
const port=process.env.PORT||8080;
const wss=new WebSocket.Server({port});
const users=new Map();
function send(ws,obj){try{if(ws&&ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));}catch(e){}}
wss.on('connection',ws=>{
 ws.on('message',raw=>{
  let m;try{m=JSON.parse(raw.toString())}catch(e){return}
  if(m.type==='register'&&m.id){
   if(ws.id&&users.has(ws.id)) users.delete(ws.id);
   users.set(m.id,{ws,name:m.name||'KEVEN'});ws.id=m.id;
   send(ws,{type:'registered',id:m.id,name:m.name||'KEVEN'}); return;
  }
  if(m.type==='users'){
   const list=[];users.forEach((u,id)=>list.push({id,name:u.name}));send(ws,{type:'users',users:list});return;
  }
  if(m.to&&users.has(m.to)) send(users.get(m.to).ws,m);
  else if(m.to) send(ws,{type:'delivery-error',to:m.to,message:'Usuario no conectado'});
 });
 ws.on('close',()=>{if(ws.id)users.delete(ws.id);});
});
console.log(`KEVEN signaling server on :${port}`);
