# KEVEN Messenger V3

Interfaz de mensajería para Android inspirada en el flujo de uso de apps modernas de chat, con diseño propio.

## Incluye
- Chats
- Conversación por ID de usuario
- Envío de mensajes mediante WebSocket al servidor de señalización
- Perfil con nombre visible y ID único
- Contactos por ID
- Sección de llamadas
- Pantalla de llamada de voz/videollamada
- Ajustes de servidor
- Workflow de GitHub Actions para generar el APK Debug

## Importante
Esta versión mejora principalmente la interfaz y la mensajería/señalización. La pantalla de llamada todavía es una base de UI: para llamadas reales de voz/video hay que completar la negociación WebRTC (PeerConnection, SDP, ICE, captura de audio/video y STUN/TURN) y desplegar el servidor de señalización en una dirección accesible desde ambos teléfonos.
