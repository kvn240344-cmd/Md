package com.keven.real;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import org.webrtc.*;
import org.webrtc.audio.JavaAudioDeviceModule;
import java.util.*;

public class CallActivity extends Activity implements PeerConnection.Observer, SdpObserver {
    private String peer, myId, myName, serverUrl;
    private boolean video, initiator;
    private SignalClient signal;
    private PeerConnectionFactory factory;
    private PeerConnection pc;
    private AudioSource audioSource;
    private VideoSource videoSource;
    private AudioTrack audioTrack;
    private VideoTrack videoTrack;
    private SurfaceViewRenderer localView, remoteView;
    private TextView state;
    private boolean makingOffer = false;
    private final List<IceCandidate> pendingRemoteCandidates = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        peer=getIntent().getStringExtra("peer"); myId=getIntent().getStringExtra("myId"); myName=getIntent().getStringExtra("myName");
        serverUrl=getIntent().getStringExtra("server"); video=getIntent().getBooleanExtra("video",false); initiator=getIntent().getBooleanExtra("initiator",false);
        buildUi();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED || (video && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.CAMERA},44);
        } else startWebRtc();
    }

    private void buildUi(){
        FrameLayout root=new FrameLayout(this); root.setBackgroundColor(Color.rgb(18,24,28));
        if(video){
            remoteView=new SurfaceViewRenderer(this); root.addView(remoteView,new FrameLayout.LayoutParams(-1,-1));
            localView=new SurfaceViewRenderer(this); FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(120,180,Gravity.TOP|Gravity.RIGHT); lp.setMargins(0,35,16,0); root.addView(localView,lp);
        }
        LinearLayout overlay=new LinearLayout(this); overlay.setOrientation(LinearLayout.VERTICAL); overlay.setGravity(Gravity.CENTER_HORIZONTAL); overlay.setPadding(24,28,24,20);
        if(!video) { TextView avatar=new TextView(this); avatar.setText("👤"); avatar.setTextSize(58); avatar.setGravity(Gravity.CENTER); overlay.addView(avatar,new LinearLayout.LayoutParams(-1,110)); }
        TextView title=new TextView(this); title.setText(video?"Videollamada":"Llamada de voz"); title.setTextSize(25); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER); overlay.addView(title,new LinearLayout.LayoutParams(-1,55));
        TextView user=new TextView(this); user.setText("@"+(peer==null?"usuario":peer)); user.setTextSize(17); user.setTextColor(Color.LTGRAY); user.setGravity(Gravity.CENTER); overlay.addView(user,new LinearLayout.LayoutParams(-1,45));
        state=new TextView(this); state.setText(initiator?"Llamando…":"Conectando…"); state.setTextSize(16); state.setTextColor(Color.LTGRAY); state.setGravity(Gravity.CENTER); overlay.addView(state,new LinearLayout.LayoutParams(-1,50));
        Space sp=new Space(this); overlay.addView(sp,new LinearLayout.LayoutParams(1,0,1));
        Button end=new Button(this); end.setText("Colgar"); end.setAllCaps(false); overlay.addView(end,new LinearLayout.LayoutParams(-1,58)); end.setOnClickListener(v->hangup());
        FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(-1,-1); root.addView(overlay,op); setContentView(root);
    }

    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g); if(r==44) startWebRtc();}

    private void startWebRtc(){
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions());
        factory=PeerConnectionFactory.builder().setAudioDeviceModule(JavaAudioDeviceModule.builder(this).createAudioDeviceModule()).createPeerConnectionFactory();
        List<PeerConnection.IceServer> ice=Collections.singletonList(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer());
        pc=factory.createPeerConnection(new PeerConnection.RTCConfiguration(ice),this);
        audioSource=factory.createAudioSource(new MediaConstraints()); audioTrack=factory.createAudioTrack("audio0",audioSource); pc.addTrack(audioTrack);
        if(video){ startVideo(); }
        signal=new SignalClient(new SignalClient.Listener(){public void onMessage(JSONObject o){runOnUiThread(()->handleSignal(o));} public void onStatus(String s){runOnUiThread(()->{if(state!=null&&s.startsWith("ERROR"))state.setText(s);});}});
        signal.connect(serverUrl);
        if (initiator) new android.os.Handler().postDelayed(this::createOffer, 700);
    }

    private void startVideo(){
        videoSource=factory.createVideoSource(false); videoTrack=factory.createVideoTrack("video0",videoSource);
        Camera2Enumerator e=new Camera2Enumerator(this); String[] names=e.getDeviceNames(); String front=null; for(String n:names) if(e.isFrontFacing(n)){front=n;break;} if(front==null&&names.length>0)front=names[0];
        if(front!=null){ VideoCapturer cap=e.createCapturer(front,null); if(cap!=null){ cap.initialize(SurfaceTextureHelper.create("CameraThread",EglBase.create().getEglBaseContext()),this,videoSource.getCapturerObserver()); cap.startCapture(640,480,24); }}
        EglBase egl=EglBase.create(); localView.init(egl.getEglBaseContext(),null); remoteView.init(egl.getEglBaseContext(),null); localView.setMirror(true); videoTrack.addSink(localView); pc.addTrack(videoTrack);
    }

    private void handleSignal(JSONObject o){
        try{
            if(!myId.equals(o.optString("to",""))) return;
            String t=o.optString("type");
            if("call-offer".equals(t)){ state.setText("Llamada entrante…"); String sdp=o.getString("sdp"); pc.setRemoteDescription(new SimpleSdpObserver(){public void onSetSuccess(){createAnswer();}},new SessionDescription(SessionDescription.Type.OFFER,sdp)); }
            else if("call-answer".equals(t)){ state.setText("Conectado"); pc.setRemoteDescription(new SimpleSdpObserver(){public void onSetSuccess(){}},new SessionDescription(SessionDescription.Type.ANSWER,o.getString("sdp"))); }
            else if("ice".equals(t)){ IceCandidate c=new IceCandidate(o.getString("sdpMid"),o.getInt("sdpMLineIndex"),o.getString("candidate")); pc.addIceCandidate(c); }
            else if("hangup".equals(t)){ finish(); }
        }catch(Exception e){if(state!=null)state.setText("Error de llamada");}
    }

    private void createOffer(){ pc.createOffer(new SimpleSdpObserver(){public void onCreateSuccess(SessionDescription d){pc.setLocalDescription(new SimpleSdpObserver(),d); sendSdp("call-offer",d);}},new MediaConstraints()); }
    private void createAnswer(){ pc.createAnswer(new SimpleSdpObserver(){public void onCreateSuccess(SessionDescription d){pc.setLocalDescription(new SimpleSdpObserver(),d); sendSdp("call-answer",d); state.setText("Conectando…");}},new MediaConstraints()); }
    private void sendSdp(String type,SessionDescription d){try{JSONObject o=new JSONObject();o.put("type",type);o.put("to",peer);o.put("from",myId);o.put("name",myName);o.put("sdp",d.description);o.put("video",video);signal.send(o);}catch(Exception ignored){}}

    private void hangup(){try{if(signal!=null){JSONObject o=new JSONObject();o.put("type","hangup");o.put("to",peer);o.put("from",myId);signal.send(o);}}catch(Exception ignored){} finish();}
    @Override protected void onDestroy(){if(pc!=null)pc.close();if(factory!=null)factory.dispose();if(signal!=null)signal.close();super.onDestroy();}
    @Override public void onIceCandidate(IceCandidate c){try{JSONObject o=new JSONObject();o.put("type","ice");o.put("to",peer);o.put("from",myId);o.put("sdpMid",c.sdpMid);o.put("sdpMLineIndex",c.sdpMLineIndex);o.put("candidate",c.sdp);signal.send(o);}catch(Exception ignored){}}
    @Override public void onAddStream(MediaStream s){if(video&&remoteView!=null&&s.videoTracks.size()>0)s.videoTracks.get(0).addSink(remoteView);}
    @Override public void onAddTrack(RtpReceiver r,MediaStream[] m){if(video&&remoteView!=null&&r.track() instanceof VideoTrack)((VideoTrack)r.track()).addSink(remoteView);}
    @Override public void onConnectionChange(PeerConnection.PeerConnectionState s){runOnUiThread(()->{if(state!=null)state.setText(s.toString());});}
    public void onSetSuccess(){}
    public void onCreateSuccess(SessionDescription d){}
    public void onCreateFailure(String s){if(state!=null)state.setText("Error: "+s);}
    public void onSetFailure(String s){if(state!=null)state.setText("Error: "+s);}
    public void onSignalingChange(PeerConnection.SignalingState s){} public void onIceConnectionChange(PeerConnection.IceConnectionState s){} public void onIceConnectionReceivingChange(boolean b){} public void onIceGatheringChange(PeerConnection.IceGatheringState s){} public void onIceCandidatesRemoved(IceCandidate[] c){} public void onRemoveStream(MediaStream s){} public void onDataChannel(DataChannel d){} public void onRenegotiationNeeded(){} public void onSelectedCandidatePairChanged(CandidatePairChangeEvent e){}
    private abstract static class SimpleSdpObserver implements SdpObserver{public void onCreateSuccess(SessionDescription d){} public void onSetSuccess(){} public void onCreateFailure(String s){} public void onSetFailure(String s){}}
}
