package com.keven.real;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONObject;
import java.util.UUID;

public class MainActivity extends Activity implements SignalClient.Listener {
    private static final int GREEN = Color.rgb(0, 145, 125);
    private static final int DARK = Color.rgb(25, 31, 36);
    private static final int BG = Color.rgb(247, 249, 250);
    private static final int MUTED = Color.rgb(110, 120, 128);

    private LinearLayout root, content;
    private TextView title, status, profileName, profileId;
    private EditText serverField, peerField, messageField, nameField;
    private SignalClient signal;
    private String myId;
    private String myName;
    private SharedPreferences prefs;
    private int currentTab = 0;

    private TextView tv(String text, float size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(DARK);
        v.setGravity(Gravity.CENTER_VERTICAL);
        return v;
    }

    private TextView label(String text) {
        TextView v = tv(text, 13);
        v.setTextColor(MUTED);
        v.setPadding(20, 16, 20, 8);
        return v;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("keven", MODE_PRIVATE);
        myId = prefs.getString("id", null);
        if (myId == null) {
            myId = UUID.randomUUID().toString().substring(0, 8);
            prefs.edit().putString("id", myId).apply();
        }
        myName = prefs.getString("name", "KEVEN");
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA}, 10);
        buildShell();
        showChats();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(18, 10, 10, 10);
        bar.setBackgroundColor(Color.WHITE);

        title = tv("Chats", 24);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0, 64, 1));
        TextView search = tv("⌕", 32);
        search.setGravity(Gravity.CENTER);
        bar.addView(search, lp(55, 64));
        TextView menu = tv("⋮", 30);
        menu.setGravity(Gravity.CENTER);
        bar.addView(menu, lp(45, 64));
        menu.setOnClickListener(v -> showSettings());
        root.addView(bar);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setBackgroundColor(Color.WHITE);
        String[] names = {"💬\nChats", "📞\nLlamadas", "👥\nContactos", "⚙\nAjustes"};
        for (int i = 0; i < names.length; i++) {
            final int tab = i;
            TextView item = tv(names[i], 13);
            item.setGravity(Gravity.CENTER);
            item.setPadding(2, 5, 2, 5);
            nav.addView(item, new LinearLayout.LayoutParams(0, 68, 1));
            item.setOnClickListener(v -> switchTab(tab));
        }
        root.addView(nav);
        setContentView(root);
    }

    private void switchTab(int tab) {
        currentTab = tab;
        if (tab == 0) showChats();
        else if (tab == 1) showCalls();
        else if (tab == 2) showContacts();
        else showSettings();
    }

    private void clearContent(String heading) {
        content.removeAllViews();
        title.setText(heading);
    }

    private TextView avatar(String name) {
        TextView a = tv(name.length() == 0 ? "?" : name.substring(0,1).toUpperCase(), 21);
        a.setTextColor(Color.WHITE);
        a.setGravity(Gravity.CENTER);
        a.setBackgroundColor(GREEN);
        return a;
    }

    private void showChats() {
        clearContent("Chats");
        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setPadding(14, 12, 14, 8);
        EditText search = new EditText(this);
        search.setHint("Buscar chats");
        search.setSingleLine();
        searchRow.addView(search, new LinearLayout.LayoutParams(0, 55, 1));
        content.addView(searchRow);

        TextView intro = tv("Mensajería privada y llamadas", 14);
        intro.setTextColor(MUTED);
        intro.setPadding(20, 6, 20, 16);
        content.addView(intro);

        addChatRow("Nueva conversación", "Escribe el ID de un usuario para comenzar", "✚", v -> openChat(null));
        addChatRow("Tu perfil", myName + "  •  @" + myId, "👤", v -> showSettings());

        Space sp = new Space(this);
        content.addView(sp, new LinearLayout.LayoutParams(1, 0, 1));
        status = tv("DESCONECTADO", 13);
        status.setTextColor(MUTED);
        status.setPadding(20, 5, 20, 5);
        content.addView(status);
        Button connect = button("Conectar al servidor");
        connect.setOnClickListener(v -> connectServer());
        content.addView(connect, lp(-1, 55));
    }

    private void addChatRow(String name, String sub, String icon, View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(16, 10, 10, 10);
        TextView a = avatar(icon);
        row.addView(a, lp(52, 52));
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setPadding(15, 0, 5, 0);
        TextView n = tv(name, 17); n.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView s = tv(sub, 13); s.setTextColor(MUTED);
        texts.addView(n); texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, 72, 1));
        row.setOnClickListener(click);
        content.addView(row);
    }

    private void openChat(String presetPeer) {
        clearContent("Conversación");
        LinearLayout head = new LinearLayout(this);
        head.setPadding(16, 8, 16, 8);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = tv("‹", 34); back.setGravity(Gravity.CENTER);
        head.addView(back, lp(45, 55));
        back.setOnClickListener(v -> showChats());
        TextView who = tv("Nuevo contacto", 19); who.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        head.addView(who, new LinearLayout.LayoutParams(0, 55, 1));
        TextView call = tv("📞", 24); call.setGravity(Gravity.CENTER);
        TextView vid = tv("📹", 24); vid.setGravity(Gravity.CENTER);
        head.addView(call, lp(48,55)); head.addView(vid, lp(48,55));
        content.addView(head);

        peerField = new EditText(this);
        peerField.setHint("ID del usuario (ej. a1b2c3d4)");
        peerField.setSingleLine();
        if (presetPeer != null) peerField.setText(presetPeer);
        content.addView(peerField, lp(-1, 60));

        TextView messages = tv("Aquí aparecerán los mensajes de esta conversación.\n\nEscribe abajo para enviar.", 15);
        messages.setTextColor(MUTED);
        messages.setPadding(20, 25, 20, 20);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(messages);
        content.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = new LinearLayout(this);
        composer.setPadding(8, 5, 8, 8);
        messageField = new EditText(this); messageField.setHint("Mensaje"); messageField.setSingleLine();
        composer.addView(messageField, new LinearLayout.LayoutParams(0, 55, 1));
        Button send = button("Enviar");
        composer.addView(send, lp(85,55));
        content.addView(composer);

        send.setOnClickListener(v -> sendMessage(messages));
        call.setOnClickListener(v -> startCall(false));
        vid.setOnClickListener(v -> startCall(true));
    }

    private void sendMessage(TextView messages) {
        if (signal == null) { Toast.makeText(this, "Conecta primero al servidor", Toast.LENGTH_SHORT).show(); return; }
        String to = peerField.getText().toString().trim();
        String text = messageField.getText().toString().trim();
        if (to.length() == 0 || text.length() == 0) return;
        try {
            JSONObject m = new JSONObject();
            m.put("type", "chat"); m.put("to", to); m.put("from", myId); m.put("name", myName); m.put("text", text);
            signal.send(m);
            messages.append("\n\nTú\n" + text);
            messageField.setText("");
        } catch (Exception e) { Toast.makeText(this, "No se pudo enviar", Toast.LENGTH_SHORT).show(); }
    }

    private void connectServer() {
        showSettings();
        Button connect = button("CONECTAR");
        content.addView(connect);
        connect.setOnClickListener(v -> {
            if (serverField == null) return;
            signal = new SignalClient(this);
            signal.connect(serverField.getText().toString().trim());
        });
    }

    private void startCall(boolean video) {
        if (signal == null) { Toast.makeText(this, "Conecta primero al servidor", Toast.LENGTH_SHORT).show(); return; }
        String peer = peerField == null ? "" : peerField.getText().toString().trim();
        if (peer.length() == 0) { Toast.makeText(this, "Escribe el ID del contacto", Toast.LENGTH_SHORT).show(); return; }
        try { JSONObject req=new JSONObject(); req.put("type","call-request"); req.put("to",peer); req.put("from",myId); req.put("name",myName); req.put("video",video); signal.send(req); } catch(Exception ignored) {}
        Intent i = new Intent(this, CallActivity.class);
        i.putExtra("video", video); i.putExtra("peer", peer); i.putExtra("myId", myId); i.putExtra("myName", myName); i.putExtra("server", prefs.getString("server", "ws://10.0.2.2:8080")); i.putExtra("initiator", true);
        startActivity(i);
    }

    private void acceptCall(String peer, boolean video) {
        Intent i=new Intent(this, CallActivity.class);
        i.putExtra("video", video); i.putExtra("peer", peer); i.putExtra("myId", myId); i.putExtra("myName", myName);
        i.putExtra("server", prefs.getString("server", "ws://10.0.2.2:8080")); i.putExtra("initiator", false);
        startActivity(i);
    }

    private void showCalls() {
        clearContent("Llamadas");
        TextView empty = tv("📞\n\nAún no tienes llamadas\n\nLas llamadas de voz y video aparecerán aquí.", 18);
        empty.setGravity(Gravity.CENTER); empty.setTextColor(MUTED);
        content.addView(empty, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    private void showContacts() {
        clearContent("Contactos");
        EditText id = new EditText(this); id.setHint("ID del usuario"); id.setSingleLine();
        content.addView(id, lp(-1,60));
        Button open = button("Abrir conversación"); content.addView(open, lp(-1,55));
        open.setOnClickListener(v -> openChat(id.getText().toString().trim()));
        TextView help = tv("Cada usuario tiene un ID único. En una próxima versión podremos añadir contactos, foto de perfil y sincronización.", 15);
        help.setTextColor(MUTED); help.setPadding(20, 20, 20, 20); content.addView(help);
    }

    private void showSettings() {
        clearContent("Ajustes");
        content.addView(label("PERFIL"));
        nameField = new EditText(this); nameField.setHint("Tu nombre"); nameField.setText(myName); nameField.setSingleLine();
        content.addView(nameField, lp(-1,60));
        profileName = tv("Nombre visible: " + myName, 15); profileName.setPadding(20, 5, 20, 10); content.addView(profileName);
        profileId = tv("Tu ID: @" + myId, 15); profileId.setPadding(20, 5, 20, 10); content.addView(profileId);
        Button save = button("Guardar perfil"); content.addView(save, lp(-1,55));
        save.setOnClickListener(v -> {
            String n = nameField.getText().toString().trim();
            if (n.length() == 0) n = "KEVEN";
            myName = n; prefs.edit().putString("name", myName).apply();
            profileName.setText("Nombre visible: " + myName);
            Toast.makeText(this, "Perfil guardado", Toast.LENGTH_SHORT).show();
        });
        content.addView(label("SERVIDOR"));
        serverField = new EditText(this); serverField.setSingleLine(); serverField.setText(prefs.getString("server", "ws://10.0.2.2:8080"));
        content.addView(serverField, lp(-1,60));
        Button connect = button("Conectar"); content.addView(connect, lp(-1,55));
        connect.setOnClickListener(v -> {
            prefs.edit().putString("server", serverField.getText().toString().trim()).apply();
            signal = new SignalClient(this); signal.connect(serverField.getText().toString().trim());
        });
        Button disconnect = button("Desconectar"); content.addView(disconnect, lp(-1,55));
        disconnect.setOnClickListener(v -> { if (signal != null) signal.close(); signal = null; Toast.makeText(this, "Desconectado", Toast.LENGTH_SHORT).show(); });
    }

    @Override public void onMessage(JSONObject o) {
        runOnUiThread(() -> {
            String type = o.optString("type", "");
            if ("chat".equals(type)) {
                Toast.makeText(this, "Mensaje de " + o.optString("name", o.optString("from", "usuario")) + ": " + o.optString("text", ""), Toast.LENGTH_LONG).show();
            } else if ("call-request".equals(type)) {
                String from=o.optString("from",""); String name=o.optString("name",from); boolean v=o.optBoolean("video",false);
                new AlertDialog.Builder(this).setTitle(v ? "Videollamada entrante" : "Llamada entrante")
                    .setMessage(name + " (@" + from + ") quiere llamarte.")
                    .setNegativeButton("Rechazar", null)
                    .setPositiveButton("Aceptar", (d,w)->acceptCall(from,v)).show();
            } else if (status != null) status.setText("SEÑAL: " + type);
        });
    }

    @Override public void onStatus(String s) {
        runOnUiThread(() -> {
            if (status != null) status.setText(s);
            if ("CONNECTED".equals(s) && signal != null) {
                try {
                    JSONObject reg = new JSONObject();
                    reg.put("type", "register"); reg.put("id", myId); reg.put("name", myName);
                    signal.send(reg);
                } catch (Exception ignored) {}
            }
        });
    }

    @Override protected void onDestroy() {
        if (signal != null) signal.close();
        super.onDestroy();
    }
}
