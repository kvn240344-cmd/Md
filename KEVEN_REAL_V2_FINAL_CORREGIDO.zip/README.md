# KEVEN REAL V2
This version starts the real architecture: Android client + WebRTC dependency + signaling server.

Important:
- Real calls need a reachable signaling server.
- The included server is only signaling; WebRTC carries media directly when possible.
- Google/Firebase authentication is intentionally not hard-coded because each app needs its own Firebase project configuration.
- The next integration step is a complete WebRTC offer/answer + ICE exchange and secure WSS deployment.


Corrección V2: el cliente WebSocket usa OkHttp para ser compatible con Android; se eliminó java.net.http, que no está disponible en el entorno Android de compilación.
