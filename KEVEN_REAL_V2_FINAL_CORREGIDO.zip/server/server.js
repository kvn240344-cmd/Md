const WebSocket=require('ws');
const wss=new WebSocket.Server({port:8080});
const users=new Map();
wss.on('connection',ws=>{
  ws.on('message',raw=>{
    let m; try{m=JSON.parse(raw)}catch(e){return}
    if(m.type==='register'&&m.id){users.set(m.id,ws);ws.id=m.id;ws.send(JSON.stringify({type:'registered',id:m.id}));}
    else if(m.to && users.has(m.to)){users.get(m.to).send(JSON.stringify(m));}
  });
  ws.on('close',()=>{if(ws.id)users.delete(ws.id);});
});
console.log('KEVEN signaling server on :8080');
