# KEVEN signaling server
This is only the signaling layer. It does not carry the audio/video.
Run with Node.js: npm install && node server.js
For two phones over the Internet, host this server on a public HTTPS/WSS endpoint.
The Android client must then use `wss://your-host:port`.
