package com.keven.real;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.util.UUID;

public class MainActivity extends Activity implements SignalClient.Listener {
    EditText server, peer; TextView status; SignalClient signal;
    String myId=UUID.randomUUID().toString().substring(0,8);

    TextView t(String s,int z){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setPadding(20,15,20,15);return v;}
    Button b(String s){Button x=new Button(this);x.setText(s);return x;}

    public void onCreate(Bundle x){super.onCreate(x); requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.CAMERA},10); home();}

    void home(){
        LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(20,20,20,20);
        TextView h=t("KEVEN",32);h.setGravity(17);r.addView(h);
        r.addView(t("Tu ID: @"+myId,18));
        server=new EditText(this);server.setHint("ws://TU_SERVIDOR:8080");server.setText("ws://10.0.2.2:8080");r.addView(server);
        Button connect=b("CONECTAR AL SERVIDOR");r.addView(connect);
        status=t("DESCONECTADO",16);r.addView(status);
        peer=new EditText(this);peer.setHint("ID del otro usuario");r.addView(peer);
        Button call=b("📞 LLAMAR");r.addView(call);
        Button video=b("📹 VIDEOLLAMAR");r.addView(video);
        setContentView(r);
        connect.setOnClickListener(v->{signal=new SignalClient(this);signal.connect(server.getText().toString().trim());});
        call.setOnClickListener(v->startCall(false));
        video.setOnClickListener(v->startCall(true));
    }
    void startCall(boolean video){
        if(signal==null){Toast.makeText(this,"Conecta primero al servidor",Toast.LENGTH_SHORT).show();return;}
        Intent i=new Intent(this,CallActivity.class);i.putExtra("video",video);i.putExtra("peer",peer.getText().toString());startActivity(i);
    }
    public void onMessage(JSONObject o){runOnUiThread(()->status.setText("SEÑAL RECIBIDA: "+o.toString()));}
    public void onStatus(String s){
        runOnUiThread(()->{
            status.setText(s);
            if ("CONNECTED".equals(s) && signal != null) {
                try {
                    JSONObject reg = new JSONObject();
                    reg.put("type", "register");
                    reg.put("id", myId);
                    signal.send(reg);
                } catch (Exception ignored) {}
            }
        });
    }
}
