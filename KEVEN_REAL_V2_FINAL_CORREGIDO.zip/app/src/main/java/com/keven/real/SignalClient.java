package com.keven.real;

import org.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class SignalClient {
    public interface Listener { void onMessage(JSONObject o); void onStatus(String s); }

    private final Listener listener;
    private final OkHttpClient client = new OkHttpClient();
    private WebSocket ws;

    public SignalClient(Listener l) { listener = l; }

    public void connect(String url) {
        try {
            Request request = new Request.Builder().url(url).build();
            ws = client.newWebSocket(request, new WebSocketListener() {
                @Override public void onOpen(WebSocket webSocket, Response response) {
                    listener.onStatus("CONNECTED");
                }

                @Override public void onMessage(WebSocket webSocket, String text) {
                    try { listener.onMessage(new JSONObject(text)); }
                    catch (Exception ignored) {}
                }

                @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                    listener.onStatus("ERROR: " + (t.getMessage() == null ? "connection failed" : t.getMessage()));
                }

                @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                    listener.onStatus("DISCONNECTED");
                }
            });
        } catch (Exception e) {
            listener.onStatus("ERROR: " + e.getMessage());
        }
    }

    public void send(JSONObject o) {
        if (ws != null) ws.send(o.toString());
    }

    public void close() {
        if (ws != null) { ws.close(1000, "bye"); ws = null; }
        client.dispatcher().executorService().shutdown();
    }
}
