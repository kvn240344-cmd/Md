package com.keven.messenger
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.*

class MainActivity: Activity() {
 private val purple=Color.rgb(103,80,164)
 private fun btn(t:String)=Button(this).apply{ text=t; isAllCaps=false; setTextColor(Color.WHITE)
   background=GradientDrawable().apply{setColor(purple);cornerRadius=28f} }
 override fun onCreate(b:Bundle?){super.onCreate(b);home()}
 private fun home(){
  val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,42,28,24)}
  l.addView(TextView(this).apply{text="Keven";textSize=34f},LinearLayout.LayoutParams(-1,80))
  l.addView(TextView(this).apply{text="Comunicación sin número telefónico";textSize=16f},LinearLayout.LayoutParams(-1,55))
  val x=btn("Continuar con Google"); l.addView(x,LinearLayout.LayoutParams(-1,58))
  x.setOnClickListener{Toast.makeText(this,"Demo: OAuth de Google será conectado en el siguiente módulo.",Toast.LENGTH_LONG).show();chats()}
  setContentView(l)
 }
 private fun chats(){
  val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,34,24,20)}
  l.addView(TextView(this).apply{text="Chats";textSize=30f},LinearLayout.LayoutParams(-1,70))
  l.addView(EditText(this).apply{hint="Buscar por correo o ID";setSingleLine()},LinearLayout.LayoutParams(-1,60))
  l.addView(TextView(this).apply{text="\nTodavía no tienes chats.\n\nBusca un contacto por correo o agrega uno mediante QR.";textSize=17f;gravity=Gravity.CENTER},
    LinearLayout.LayoutParams(-1,0,1f))
  val r=LinearLayout(this); val q=btn("Escanear QR"); val c=btn("Llamadas")
  r.addView(q,LinearLayout.LayoutParams(0,58,1f));r.addView(c,LinearLayout.LayoutParams(0,58,1f))
  l.addView(r);q.setOnClickListener{Toast.makeText(this,"Demo QR.",Toast.LENGTH_SHORT).show()}
  c.setOnClickListener{Toast.makeText(this,"Demo WebRTC.",Toast.LENGTH_SHORT).show()};setContentView(l)
 }
}